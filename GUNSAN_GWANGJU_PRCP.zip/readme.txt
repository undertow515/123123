# Korean Weather Data Collection

This repository contains precipitation and temperature data collected from Korean Meteorological Administration (KMA) weather stations.

## Data Period
**1972 ~ September 9, 2025**

## Data Types

### Daily Data
Daily precipitation and temperature measurements from ASOS (Automated Surface Observing System) stations.

#### Variables
- `precip_mm`: Daily precipitation (mm)
- `prcp_d99`: 9-9 precipitation (mm) - precipitation measured from 09:00 to 09:00 next day
- `prcp_dur_hr`: Precipitation duration (hours)
- `prcp_60m_max`: Maximum 1-hour precipitation (mm)
- `prcp_60m_max_time`: Time of maximum 1-hour precipitation (HHMM)
- `prcp_10m_max`: Maximum 10-minute precipitation (mm)
- `prcp_10m_max_time`: Time of maximum 10-minute precipitation (HHMM)
- `prcp_intensity_max`: Maximum precipitation intensity (mm/h)
- `prcp_intensity_max_time`: Time of maximum precipitation intensity (HHMM)
- `temp_min`: Minimum temperature (°C)
- `temp_max`: Maximum temperature (°C)
- `temp_avg`: Average temperature (°C)
- `station_id`: Weather station ID

#### Stations
- **Gunsan (ks)**: Station ID 140
- **Gwangju (gj)**: Station ID 156

### Hourly Data
Hourly precipitation data available in two versions:

#### 1. ASOS Data
High-quality data from ASOS stations with quality control and validation.

#### 2. AWS Data  
Data from AWS (Automatic Weather Station) - disaster prevention meteorological stations.

**Note**: AWS data for 2025 may have lower quality as it has not undergone quality control and validation processes, unlike ASOS data.

## File Naming Convention
- `gj_`: Gwangju station data
- `ks_`: Gunsan station data
- `daily`: Daily measurements
- `hourly`: Hourly measurements
- `aws`: AWS (Automatic Weather Station) data
- `asos`: ASOS (Automated Surface Observing System) data

## Data Quality
- **ASOS data**: Quality controlled and validated
- **AWS data**: Raw automatic measurements, especially 2025 data may contain quality issues

## Station Information
All data can be distinguished by the `station_id` field within the files:
- Station 140: Gunsan ASOS
- Station 156: Gwangju ASOS

## Data Source
Korean Meteorological Administration (KMA) API

## Usage Notes
1. Use ASOS data for research requiring high data quality
2. Be cautious when using 2025 AWS data due to potential quality issues
3. Missing values are represented as NaN in the processed data
4. All times are in Korean Standard Time (KST)

## Contact
For questions about data collection methods or issues, please refer to the KMA API documentation or contact the data maintainer.